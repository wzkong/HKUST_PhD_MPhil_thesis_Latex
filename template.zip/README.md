HKUST_PhD/MPhil_thesis_Latex
======================

*This template can also be used in MPhil thesis after changing all "PhD" to "MPhil".*

This is a HKUST PhD/MPhil thesis latex template based on the latest official sample (http://pg.ust.hk/guides_n_forms/students/thesis_sample_page.pdf)

I know there are other latex templates for PhD/MPhil students of HKUST. But they are old and difficult to modify. I create this one based on the latest official sample which is different from the older one. This one is designed to be as easy/straightforward as I can. Almost every page can be modified directly. Suitable for beginners.

Please report issues if there is any questions or requirements.
